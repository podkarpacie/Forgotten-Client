FORGOTTEN CLIENT 7.4
====================

A clean 7.4 Tibia client for Forgotten Engine (https://github.com/podkarpacie/Forgotten-Engine).

GETTING STARTED (2 steps)
-------------------------
1. Drop your 7.4 client files into this folder:
     data/things/740/Tibia.dat
     data/things/740/Tibia.spr
   (legal, operator-supplied assets - nothing is bundled/redistributed)

2. Make sure Forgotten Engine and this client share the same login RSA key:
   - Generate the engine key:  forgotten-engine generate-key <world>
   - Put the matching modulus into  modules/gamelib/const.lua  (FE_RSA)

3. Run:  ForgottenClient.exe
   Default login server: 127.0.0.1:7172  protocol 740.

REQUIREMENTS
------------
Windows 10/11 64-bit. No install required - unzip and run.

PACKAGE CONTENTS
----------------
ForgottenClient.exe   the client
*.dll                 required runtime libraries
init.lua, data/, modules/, mods/   client resources

Significant configuration lives in modules/ and data/; a settings file
(forgottenclient.log/forgottenclient.json) is created next to the exe on first run.

SOURCE CODE
-----------
This ZIP is a runnable build only. Source lives at:
  https://github.com/podkarpacie/Forgotten-Client

LICENSE
-------
MIT. Derived from OTClient (edubart) and Midgard (sp4wna1).
